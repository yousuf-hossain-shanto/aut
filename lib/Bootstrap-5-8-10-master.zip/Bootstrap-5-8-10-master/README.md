# Bootstrap-5-8-10
<h3>Support more  number of columns in Bootstrap, column 5, column 8 and column 10</h3>

Bootstrap - The most loved CSS framework amongst the UI developers lets you use a grid system of 12 columns. So that means, If you want to create columns with same sizes within a Row,  you can choose column numbers between 1,2,3,4,6 and 12.

Bootstrap-5-8-10 Lets you define more  number of equal sized  columns, i.e column 5, column 8 and column 10, while using the bootstrap grid system.

<h3>Usage</h3>
<ul>
<li>Download Bootstrap-5-8-10, and add to your html file below bootstrap.css</li>
<li>use columns as, col-*-5-12: for five column layout, col-*-8-12: for 8 column layout, col-*-10-12: for 10 column layout</li>
</ul>





Example: you can see this <a href='http://plnkr.co/edit/p7oGgcfZSqJrK5T9nrI7?p=preview'>plunker</a> 
